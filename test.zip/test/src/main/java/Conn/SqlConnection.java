package Conn;

import java.sql.DriverManager;
import java.sql.*;

public class SqlConnection {
    public static Connection getConnection(){
        Connection con = null;
        String url = "jdbc:mysql://localhost:3306/logistics";
        String username = "root";
        String password = "shan-root";
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(url,username,password);
        }
        catch(Exception e){
            System.out.println(e);
        }
        return con;
    }
}
