package Redis;

import redis.clients.jedis.JedisPool;
import redis.clients.jedis.Jedis;

public class RedisFunctionalities {
    Jedis jedis = new Jedis();
    JedisPool jedisPool = new JedisPool("localhost", 6379);
    public void setCache(String key, String data){
        jedis.set(key,data);
    }
    public String getCache(String key){
        try (Jedis jedis = jedisPool.getResource()) {
            return jedis.get(key);
        }
    }
    public Long delCache(String key){
        return jedis.del(key);
    }
}
