package Data;

public class DriverDetail {
    private int id;
    private int ord_id;
    private int dri_id;
    private int hub_id;
    private String status;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getOrd_id() {
        return ord_id;
    }

    public void setOrd_id(int ord_id) {
        this.ord_id = ord_id;
    }

    public int getDri_id() {
        return dri_id;
    }

    public void setDri_id(int dri_id) {
        this.dri_id = dri_id;
    }
    public int getHub_id(){
        return hub_id;
    }

    public void setHub_id(int hub_id) {
        this.hub_id = hub_id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
