package Dao;
import Conn.*;
import Data.*;

import java.util.*;
import java.sql.*;
public class CustDao {
    public static int create(Customer c){
        int status = 0;
        try{
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("insert into customers(cust_name,cust_location,cust_phone,cust_email) values(?,?,?,?)");
            ps.setString(1,c.getName());
            ps.setString(2,c.getLocation());
            ps.setString(3, c.getphone());
            ps.setString(4,c.getEmail());

            status = ps.executeUpdate();
            con.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return status;
    }

    public static List<Customer> retrieve(){
        List<Customer> list = new ArrayList<>();
        try {
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from customers");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Customer cust = new Customer();
                cust.setId(rs.getInt(1));
                cust.setName(rs.getString(2));
                cust.setLocation(rs.getString(3));
                cust.setPhone(rs.getString(4));
                cust.setEmail(rs.getString(5));
                list.add(cust);
            }
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }

    public static Customer retrieveById(Customer c){
        Customer cust = new Customer();
        try{
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from customers where cust_id=?");
            ps.setInt(1,c.getId());
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                cust.setId(rs.getInt(1));
                cust.setName(rs.getString(2));
                cust.setLocation(rs.getString(3));
                cust.setPhone(rs.getString(4));
                cust.setEmail(rs.getString(5));
            }
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return cust;
    }

    public static int update(Customer c){
        int status = 0;
        try{
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("update customers set cust_name=?, cust_location=?, cust_phone=?, cust_email=? where cust_id=?");
            ps.setString(1,c.getName());
            ps.setString(2,c.getLocation());
            ps.setString(3, c.getphone());
            ps.setString(4,c.getEmail());
            ps.setInt(5,c.getId());

            status = ps.executeUpdate();
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return status;
    }

    public static int delete(Customer c){
        int status=0;
        try{
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("delete from customers where cust_id = ?");
            ps.setInt(1,c.getId());

            status = ps.executeUpdate();
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return status;
    }
}
