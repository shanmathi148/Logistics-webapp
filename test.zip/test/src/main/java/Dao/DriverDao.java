package Dao;
import Conn.*;
import Data.*;

import java.io.PrintWriter;
import java.util.*;
import java.sql.*;
public class DriverDao {
    public static int create(Drivers d){
        int status = 0;
        try{
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("insert into drivers(dri_name,dri_phone) values(?,?)");
            ps.setString(1,d.getName());
            ps.setString(2, d.getPhone());

            status = ps.executeUpdate();
            con.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return status;
    }

    public static List<Drivers> retrieve(){
        List<Drivers> list = new ArrayList<>();
        try {
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from drivers");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Drivers dri = new Drivers();
                dri.setId(rs.getInt(1));
                dri.setName(rs.getString(2));
                dri.setPhone(rs.getString(3));
                dri.setStatus(rs.getString(4));
                list.add(dri);
            }
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }

    public static Drivers retrieveById(Drivers d){
        Drivers dri = new Drivers();
        try{
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from drivers where dri_id=?");
            ps.setInt(1,d.getId());
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                dri.setId(rs.getInt(1));
                dri.setName(rs.getString(2));
                dri.setPhone(rs.getString(3));
                dri.setStatus(rs.getString(4));
            }
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return dri;
    }

    public static int update(Drivers d){
        int status = 0;
        try{
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("update drivers set dri_name=?, dri_phone=?, dri_status=? where dri_id=?");
            ps.setString(1,d.getName());
            ps.setString(2, d.getPhone());
            ps.setString(3,d.getStatus());
            ps.setInt(4,d.getId());

            status = ps.executeUpdate();
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return status;
    }

    public static int delete(Drivers d){
        int status=0;
        try{
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("delete from drivers where dri_id = ?");
            ps.setInt(1,d.getId());

            status = ps.executeUpdate();
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return status;
    }

    public static void changeStatus(int id, String status){
        try{
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("update drivers set dri_status=? where dri_id=?");
            ps.setString(1,status);
            ps.setInt(2,id);
            ps.executeUpdate();

            //check whether any order is not assigned with a driver and assign when the driver becomes free
            if(status.equals("free")){
                PreparedStatement ps2 = con.prepareStatement("select o_id from orders where not exists (select o_id from driver_details where orders.o_id = driver_details.o_id)");
                ResultSet rs = ps2.executeQuery();
                DriverDetail drd = new DriverDetail();
                if(rs.next()){
                    drd.setOrd_id(rs.getInt(1));
                    drd.setDri_id(id);

                    //finding hub id from customers
                    Order o = new Order();
                    o.setId(rs.getInt(1));
                    OrderDao dao = new OrderDao();
                    Order od = dao.retrieveById(o);
                    int custId = od.getC_id();
                    Customer cust = new Customer();
                    cust.setId(custId);
                    Customer c = CustDao.retrieveById(cust);
                    String h_loc = c.getLocation();
                    int h_id = HubDao.retrieveByLoc(h_loc);

                    drd.setHub_id(h_id);

                    int stat = DriDetailDao.create(drd);
                    DriverDao.changeStatus(id,"assigned");
                }
            }

            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }
}
