package Dao;
import Conn.*;
import Data.*;

import java.util.*;
import java.sql.*;
public class HubDao {
    public static int create(Hub h){
        int status = 0;
        try{
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("insert into hubs(hub_name,hub_location) values(?,?)");
            ps.setString(1,h.getName());
            ps.setString(2,h.getLocation());

            status = ps.executeUpdate();
            con.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return status;
    }

    public static List<Hub> retrieve(){
        List<Hub> list = new ArrayList<>();
        try {
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from hubs");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Hub hub = new Hub();
                hub.setId(rs.getInt(1));
                hub.setName(rs.getString(2));
                hub.setLocation(rs.getString(3));
                list.add(hub);
            }
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }

    public static Hub retrieveById(Hub h){
        Hub hub = new Hub();
        try{
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from hubs where hub_id=?");
            ps.setInt(1,h.getId());
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                hub.setId(rs.getInt(1));
                hub.setName(rs.getString(2));
                hub.setLocation(rs.getString(3));
            }
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return hub;
    }

    public static int retrieveByLoc(String loc){
        int id = 0;
        try{
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("select hub_id from hubs where hub_location=?");
            ps.setString(1,loc);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                id = rs.getInt(1);
            }
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return id;
    }

    public static int update(Hub h){
        int status = 0;
        try{
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("update hubs set hub_name=?, hub_location=? where hub_id=?");
            ps.setString(1,h.getName());
            ps.setString(2,h.getLocation());
            ps.setInt(3,h.getId());

            status = ps.executeUpdate();
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return status;
    }

    public static int delete(Hub h){
        int status=0;
        try{
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("delete from hubs where hub_id = ?");
            ps.setInt(1,h.getId());

            status = ps.executeUpdate();
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return status;
    }
}
