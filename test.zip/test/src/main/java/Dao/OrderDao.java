package Dao;

import Data.Order;
import Conn.SqlConnection;
import Data.OrderDetail;
import Redis.RedisFunctionalities;
import com.google.gson.Gson;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class OrderDao {
    private Gson gson = new Gson();
    public static int create(Order o){
        int id = 0;
        try{
            String[] returnId = { "o_id" };
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("insert into orders(o_date,o_description,cust_id) values(?,?,?)", returnId);
            ps.setString(1,o.getDate());
            ps.setString(2, o.getDescription());
            ps.setInt(3,o.getC_id());

            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    id = rs.getInt(1);
                }
            }
            con.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return id;
    }
    public static void calculateTotal(OrderDetail od) throws IOException {
        int ord_id = od.getO_id();
        double subTotal = od.getSub_total();
        Order o = new Order();
        o.setId(ord_id);
        OrderDao dao = new OrderDao();
        Order ord = dao.retrieveById(o);
        double total = ord.getTotal();
        total += subTotal;
        try {
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("update orders set o_total=? where o_id=?");
            ps.setDouble(1,total);
            ps.setInt(2,ord_id);
            ps.executeUpdate();
        }
        catch (Exception e){
            e.printStackTrace();
        }

    }
    public static List<Order> retrieve(){
        List<Order> list = new ArrayList<>();
        try {
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from orders");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Order ord = new Order();
                ord.setId(rs.getInt(1));
                ord.setDate(rs.getString(2));
                ord.setTotal(rs.getDouble(3));
                ord.setDescription(rs.getString(4));
                ord.setC_id(rs.getInt(5));
                ord.setStatus(rs.getString(6));
                list.add(ord);
            }
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }
    public Order retrieveById(Order o) throws IOException {
        Order ord = new Order();
        RedisFunctionalities redis = new RedisFunctionalities();
        String ORDER = "order:";
        ORDER += String.valueOf(o.getId());
        String cachedOrderJson = redis.getCache(ORDER);
        if (cachedOrderJson != null) {
            //System.out.println("from cache");
            return gson.fromJson(cachedOrderJson, Order.class);
        }
        else {
            //fetching data from the database
            //System.out.println("from database");
            try {
                Connection con = SqlConnection.getConnection();
                PreparedStatement ps = con.prepareStatement("select * from orders where o_id=?");
                ps.setInt(1, o.getId());
                ResultSet rs = ps.executeQuery();
                if (rs.next()) {
                    ord.setId(rs.getInt(1));
                    ord.setDate(rs.getString(2));
                    ord.setTotal(rs.getDouble(3));
                    ord.setDescription(rs.getString(4));
                    ord.setC_id(rs.getInt(5));
                    ord.setStatus(rs.getString(6));
                }
                redis.setCache("order:" + o.getId(), gson.toJson(ord));
                con.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return ord;
        }
    }
    public int update(Order o){
        int status = 0;
        try{
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("update orders set o_date=?, o_description=?, cust_id=?, o_status=? where o_id=?");
            ps.setString(1,o.getDate());
            ps.setString(2,o.getDescription());
            ps.setInt(3,o.getC_id());
            ps.setString(4,o.getStatus());
            ps.setInt(5,o.getId());

            status = ps.executeUpdate();

            //updating in redis
            if(status != 0){
                RedisFunctionalities redis = new RedisFunctionalities();
                String ORDER = "order:";
                ORDER += String.valueOf(o.getId());
                redis.delCache(ORDER);
                redis.setCache(ORDER, this.gson.toJson(o));
            }
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return status;
    }
    public static int delete(Order o){
        int status=0;
        int o_id = o.getId();
        try{
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("delete from orders where o_id = ?");
            ps.setInt(1,o_id);

            status = ps.executeUpdate();

            //deleting in redis
            if(status != 0){
                RedisFunctionalities redis = new RedisFunctionalities();
                String ORDER = "order:";
                ORDER += String.valueOf(o_id);
                redis.delCache(ORDER);
            }
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return status;
    }
    public static void changeStatus(int id, String status){
        try{
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("update orders set o_status=? where o_id=?");
            ps.setString(1,status);
            ps.setInt(2,id);
            ps.executeUpdate();

            RedisFunctionalities redis = new RedisFunctionalities();
            String ORDER = "order:";
            ORDER += String.valueOf(id);
            redis.delCache(ORDER);

            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }
}
