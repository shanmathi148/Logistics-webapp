package Dao;

import Conn.SqlConnection;
import Data.OrderDetail;
import Data.Product;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class OrdDetailDao {
    public static int create(OrderDetail od){
        int status = 0;
        try{
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("insert into order_details(o_id,p_id,p_count,sub_total) values(?,?,?,?)");
            ps.setInt(1,od.getO_id());
            ps.setInt(2,od.getP_id());
            ps.setInt(3, od.getP_count());
            ps.setDouble(4,od.getSub_total());

            status = ps.executeUpdate();
            con.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return status;
    }

    public static List<OrderDetail> retrieveById(OrderDetail od){
        List<OrderDetail> list = new ArrayList<>();
        try {
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from order_details where o_id=?");
            ps.setInt(1,od.getO_id());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                OrderDetail ord = new OrderDetail();
                ord.setId(rs.getInt(1));
                ord.setO_id(rs.getInt(2));
                ord.setP_id(rs.getInt(3));
                ord.setP_count(rs.getInt(4));
                ord.setSub_total(rs.getDouble(5));
                list.add(ord);
            }
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }
    public static OrderDetail retrieveByODid(int id){
        OrderDetail ord = new OrderDetail();
        try{
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from order_details where od_id=?");
            ps.setInt(1,id);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                ord.setId(rs.getInt(1));
                ord.setO_id(rs.getInt(2));
                ord.setP_id(rs.getInt(3));
                ord.setP_count(rs.getInt(4));
                ord.setSub_total(rs.getDouble(5));
            }
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return ord;
    }
    public static int update(OrderDetail od){
        int status = 0;
        try{
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("update order_details set o_id=?, p_id=?, p_count=?, sub_total=? where od_id=?");
            ps.setInt(1,od.getO_id());
            ps.setInt(2,od.getP_id());
            ps.setInt(3,od.getP_count());
            ps.setDouble(4,od.getSub_total());
            ps.setInt(5,od.getId());

            status = ps.executeUpdate();
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return status;
    }
    public static int delete(OrderDetail od){
        int status=0;
        try{
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("delete from order_details where od_id = ?");
            ps.setInt(1,od.getId());

            status = ps.executeUpdate();
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return status;
    }
    public static double cal_subTotal(int prodId, int prodCount){
        Product prod = new Product();
        prod.setId(prodId);
        Product p = ProdDao.retrieveById(prod);
        double prod_price = p.getPrice();
        double subTotal = prod_price * prodCount;
        return subTotal;
    }
}
