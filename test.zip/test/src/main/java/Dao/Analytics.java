package Dao;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class Analytics {
    public static boolean checkDateRange(String start, String end, String check){
        try {
            Date startDate = new SimpleDateFormat("dd-MM-yyyy").parse(start);
            Date endDate = new SimpleDateFormat("dd-MM-yyyy").parse(end);
            Date checkDate = new SimpleDateFormat("dd-MM-yyyy").parse(check);
            if (checkDate.before(endDate) && checkDate.after(startDate)) {
                return true;
            }
            return false;
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return false;
    }
    public static String findStartDate(LocalDate formatDate, String range){
        String startDate;
        DateTimeFormatter formatType = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDate minusDate;
        if(range.equals("1 week")){
            minusDate = formatDate.minusDays(7);
        } else if (range.equals("1 month")) {
            minusDate = formatDate.minusMonths(1);
        } else if (range.equals("6 months")) {
            minusDate = formatDate.minusMonths(6);
        } else if (range.equals("1 year")) {
            minusDate = formatDate.minusYears(1);
        } else {
            minusDate = formatDate.minusYears(100);
        }
        startDate = minusDate.format(formatType);
        return startDate;
    }
    public static LinkedHashMap<Integer, Integer> sortMap(HashMap<Integer,Integer> map){
        LinkedHashMap<Integer,Integer> sortedMap = new LinkedHashMap<>();
        ArrayList<Integer> list = new ArrayList<>();
        for (Map.Entry<Integer, Integer> entry : map.entrySet()) {
            list.add(entry.getValue());
        }
        Collections.sort(list, Collections.<Integer>reverseOrder());
        for (int num : list) {
            for (Map.Entry<Integer, Integer> entry : map.entrySet()) {
                if (entry.getValue().equals(num)) {
                    sortedMap.put(entry.getKey(), num);
                }
            }
        }
        return sortedMap;
    }
}
