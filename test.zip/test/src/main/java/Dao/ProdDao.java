package Dao;
import Conn.*;
import Data.*;

import java.util.*;
import java.sql.*;
public class ProdDao {
    public static int create(Product p){
        int status = 0;
        try{
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("insert into products(name,price,description) values(?,?,?)");
            ps.setString(1,p.getName());
            ps.setDouble(2,p.getPrice());
            ps.setString(3, p.getDescription());

            status = ps.executeUpdate();
            con.close();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return status;
    }

    public static List<Product> retrieve(){
        List<Product> list = new ArrayList<>();
        try {
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from products");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                Product prod = new Product();
                prod.setId(rs.getInt(1));
                prod.setName(rs.getString(2));
                prod.setPrice(rs.getDouble(3));
                prod.setDescription(rs.getString(4));
                list.add(prod);
            }
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }

    public static Product retrieveById(Product p){
        Product prod = new Product();
        try{
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from products where prodid=?");
            ps.setInt(1,p.getId());
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                prod.setId(rs.getInt(1));
                prod.setName(rs.getString(2));
                prod.setPrice(rs.getDouble(3));
                prod.setDescription(rs.getString(4));
            }
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return prod;
    }

    public static int update(Product p){
        int status = 0;
        try{
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("update products set name=?, price=?, description=? where prodid=?");
            ps.setString(1,p.getName());
            ps.setDouble(2,p.getPrice());
            ps.setString(3, p.getDescription());
            ps.setInt(4,p.getId());

            status = ps.executeUpdate();
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return status;
    }

    public static int delete(Product p){
        int status=0;
        try{
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("delete from products where prodid = ?");
            ps.setInt(1,p.getId());

            status = ps.executeUpdate();
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return status;
    }
}
