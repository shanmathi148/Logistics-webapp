package Dao;

import Conn.SqlConnection;
import Data.DriverDetail;
import Data.Drivers;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class DriDetailDao {
    public static int create(DriverDetail dd){
        int status = 0;
        try{
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("insert into driver_details(o_id, d_id, h_id) values(?,?,?)");
            ps.setInt(1,dd.getOrd_id());
            ps.setInt(2,dd.getDri_id());
            ps.setInt(3,dd.getHub_id());

            status = ps.executeUpdate();
            con.close();
            return status;
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return status;
    }
    public static List<DriverDetail> retrieve(){
        List<DriverDetail> list = new ArrayList<>();
        try {
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from driver_details");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                DriverDetail drd = new DriverDetail();
                drd.setId(rs.getInt(1));
                drd.setOrd_id(rs.getInt(2));
                drd.setDri_id(rs.getInt(3));
                drd.setHub_id(rs.getInt(4));
                drd.setStatus(rs.getString(5));
                list.add(drd);
            }
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }
    public static DriverDetail retrieveById(DriverDetail dd) {
        DriverDetail drd = new DriverDetail();
        try {
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from driver_details where o_id=?");
            ps.setInt(1, dd.getOrd_id());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                drd.setId(rs.getInt(1));
                drd.setOrd_id(rs.getInt(2));
                drd.setDri_id(rs.getInt(3));
                drd.setHub_id(rs.getInt(4));
                drd.setStatus(rs.getString(5));
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return drd;
    }
    public static int update(DriverDetail dd){
        int status = 0;
        try{
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("update driver_details set o_id=?, d_id=?, h_id=?, status=? where id=?");
            ps.setInt(1,dd.getOrd_id());
            ps.setInt(2,dd.getDri_id());
            ps.setInt(3,dd.getHub_id());
            ps.setString(4,dd.getStatus());
            ps.setInt(5,dd.getId());

            status = ps.executeUpdate();
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return status;
    }
    public static int delete(DriverDetail dd){
        int status=0;
        try{
            Connection con = SqlConnection.getConnection();

            //changing the status of the driver
            PreparedStatement ps = con.prepareStatement("select d_id from driver_details where id = ?");
            ps.setInt(1,dd.getId());
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                int id = rs.getInt(1);
                System.out.println(id);
                DriverDao.changeStatus(id, "free");
            }

            PreparedStatement ps2 = con.prepareStatement("delete from driver_details where id = ?");
            ps2.setInt(1,dd.getId());
            status = ps2.executeUpdate();
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return status;
    }
    public static void changeStatus(int id, String status){
        try{
            Connection con = SqlConnection.getConnection();
            PreparedStatement ps = con.prepareStatement("update driver_details set status=? where id=?");
            ps.setString(1,status);
            ps.setInt(2,id);
            ps.executeUpdate();
            con.close();
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }
}
