package Servlets.Products;

import Dao.ProdDao;
import Data.Product;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "Servlets.Products.ProdRetrieveByIdServlet", value = "/Servlets.Products.ProdRetrieveByIdServlet")
public class ProdRetrieveByIdServlet extends HttpServlet {
    private Gson gson = new Gson();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BufferedReader reader = request.getReader();
        JsonObject jsonData = JsonParser.parseReader(reader).getAsJsonObject();
        int prodId = jsonData.get("id").getAsInt();

        Product prod = new Product();
        prod.setId(prodId);
        Product p = ProdDao.retrieveById(prod);

        PrintWriter out = response.getWriter();
        JsonObject responseObject = new JsonObject();
        response.setContentType("application/json");
        String prodJsonString = this.gson.toJson(p);
        JsonElement prodJson = gson.fromJson(prodJsonString,JsonElement.class);
        if(p.getId() != 0){
            responseObject.addProperty("status","success");
            responseObject.addProperty("comment","Product found at the given id");
            responseObject.add("data",prodJson);
        }
        else{
            responseObject.addProperty("status","failed");
            responseObject.addProperty("comment","Product not found");
        }
        out.print(responseObject);
        out.flush();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}