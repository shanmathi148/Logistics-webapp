package Servlets.Products;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.*;

import Dao.ProdDao;
import Data.*;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.JsonObject;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "Servlets.Products.ProdCreateServlet", value = "/Servlets.Products.ProdCreateServlet")
public class ProdCreateServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    }
    private Gson gson = new Gson();
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BufferedReader reader = request.getReader();
        JsonObject jsonData = JsonParser.parseReader(reader).getAsJsonObject();
        String prodName = jsonData.get("name").getAsString();
        double prodPrice = jsonData.get("price").getAsDouble();
        String prodDes = jsonData.get("description").getAsString();

        Product prod = new Product();
        prod.setName(prodName);
        prod.setPrice(prodPrice);
        prod.setDescription(prodDes);
        int status = ProdDao.create(prod);

        PrintWriter out = response.getWriter();
        String prodJsonString = this.gson.toJson(prod);
        JsonElement prodJson = gson.fromJson(prodJsonString,JsonElement.class);
        JsonObject responseObject = new JsonObject();
        response.setContentType("application/json");
        if(status>0){
            responseObject.addProperty("status","success");
            responseObject.addProperty("comment","Product created successfully");
            responseObject.add("data",prodJson);
        }
        else{
            responseObject.addProperty("status","failed");
            responseObject.addProperty("comment","Product not created");
        }
        out.print(responseObject);
        out.flush();
    }
}