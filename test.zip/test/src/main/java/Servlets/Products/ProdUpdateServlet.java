package Servlets.Products;

import Dao.ProdDao;
import Data.Product;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "Servlets.Products.ProdUpdateServlet", value = "/Servlets.Products.ProdUpdateServlet")
public class ProdUpdateServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    }
    private Gson gson = new Gson();
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BufferedReader reader = request.getReader();
        JsonObject jsonData = JsonParser.parseReader(reader).getAsJsonObject();
        int prodId = jsonData.get("id").getAsInt();
        String prodName = jsonData.get("name").getAsString();
        double prodPrice = jsonData.get("price").getAsDouble();
        String prodDes = jsonData.get("description").getAsString();

        Product prod = new Product();
        prod.setId(prodId);
        prod.setName(prodName);
        prod.setPrice(prodPrice);
        prod.setDescription(prodDes);
        int status = ProdDao.update(prod);

        PrintWriter out = response.getWriter();
        String prodJsonString = this.gson.toJson(prod);
        JsonElement prodJson = gson.fromJson(prodJsonString,JsonElement.class);
        JsonObject responseObject = new JsonObject();
        response.setContentType("application/json");
        if(status>0){
            responseObject.addProperty("status","success");
            responseObject.addProperty("comment","Product details updated successfully");
            responseObject.add("data",prodJson);
        }
        else{
            responseObject.addProperty("status","failed");
            responseObject.addProperty("comment","Product details not updated");
        }
        out.print(responseObject);
        out.flush();
    }
}