package Servlets.Products;

import Dao.ProdDao;
import Data.Product;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "Servlets.Products.ProdDeleteServlet", value = "/Servlets.Products.ProdDeleteServlet")
public class ProdDeleteServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BufferedReader reader = request.getReader();
        JsonObject jsonData = JsonParser.parseReader(reader).getAsJsonObject();
        int prodId = jsonData.get("id").getAsInt();

        Product prod = new Product();
        prod.setId(prodId);
        int status = ProdDao.delete(prod);

        PrintWriter out = response.getWriter();
        JsonObject responseObject = new JsonObject();
        response.setContentType("application/json");
        if(status>0){
            responseObject.addProperty("status","success");
            responseObject.addProperty("comment","Product deleted successfully");
        }
        else{
            responseObject.addProperty("status","failed");
            responseObject.addProperty("comment","Product not deleted");
        }
        out.print(responseObject);
        out.flush();
    }
}