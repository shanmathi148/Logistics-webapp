package Servlets.Products;

import Dao.ProdDao;
import Data.Product;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;

@WebServlet(name = "Servlets.Products.ProdRetrieveServlet", value = "/Servlets.Products.ProdRetrieveServlet")
public class ProdRetrieveServlet extends HttpServlet {
    private Gson gson = new Gson();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        response.setContentType("application/json");
        JsonObject responseObject = new JsonObject();
        List<Product> list = ProdDao.retrieve();
        if(!list.isEmpty()) {
            for (Product p : list) {
                String prodJsonString = this.gson.toJson(p);
                out.print(prodJsonString);
            }
        }
        else{
            responseObject.addProperty("status","failed");
            responseObject.addProperty("comment","Product list is empty");
            out.print(responseObject);
        }
        out.flush();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}