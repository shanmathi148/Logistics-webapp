package Servlets.DriverDetails;

import Dao.DriDetailDao;
import Data.DriverDetail;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet(name = "DDRetrieveServlet", value = "/DDRetrieveServlet")
public class DDRetrieveServlet extends HttpServlet {
    private Gson gson = new Gson();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        response.setContentType("application/json");
        JsonObject responseObject = new JsonObject();
        List<DriverDetail> list = DriDetailDao.retrieve();
        if(!list.isEmpty()) {
            for (DriverDetail d : list) {
                String drdJsonString = this.gson.toJson(d);
                out.print(drdJsonString);
            }
        }
        else{
            responseObject.addProperty("status","failed");
            responseObject.addProperty("comment","Driver details list is empty");
            out.print(responseObject);
        }
        out.flush();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}