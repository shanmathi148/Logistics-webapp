package Servlets.DriverDetails;

import Dao.DriDetailDao;
import Dao.DriverDao;
import Dao.OrderDao;
import Data.DriverDetail;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "DDUpdateServlet", value = "/DDUpdateServlet")
public class DDUpdateServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
    private Gson gson = new Gson();
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BufferedReader reader = request.getReader();
        JsonObject jsonData = JsonParser.parseReader(reader).getAsJsonObject();
        int id = jsonData.get("id").getAsInt();
        int ordId = jsonData.get("o_id").getAsInt();
        int driId = jsonData.get("d_id").getAsInt();
        int hubId = jsonData.get("h_id").getAsInt();
        String o_status = jsonData.get("status").getAsString();

        DriverDetail drd = new DriverDetail();
        drd.setId(id);
        drd.setOrd_id(ordId);
        drd.setDri_id(driId);
        drd.setHub_id(hubId);
        drd.setStatus(o_status);
        int status = DriDetailDao.update(drd);

        PrintWriter out = response.getWriter();
        String drdJsonString = this.gson.toJson(drd);
        JsonElement drdJson = gson.fromJson(drdJsonString,JsonElement.class);
        JsonObject responseObject = new JsonObject();
        response.setContentType("application/json");
        if(status>0){
            responseObject.addProperty("status","success");
            responseObject.addProperty("comment","Driver details updated successfully");
            responseObject.add("data",drdJson);

            //changing status of driver and order if order is delivered
            if(o_status.equals("delivered")){
                DriverDao.changeStatus(driId,"free");
                OrderDao.changeStatus(ordId,"delivered");
            }
        }
        else{
            responseObject.addProperty("status","failed");
            responseObject.addProperty("comment","Driver details not updated");
        }
        out.print(responseObject);
        out.flush();
    }
}