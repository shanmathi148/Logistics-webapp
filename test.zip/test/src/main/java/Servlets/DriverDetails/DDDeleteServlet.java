package Servlets.DriverDetails;

import Dao.DriDetailDao;
import Dao.DriverDao;
import Dao.OrderDao;
import Data.DriverDetail;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "DDDeleteServlet", value = "/DDDeleteServlet")
public class DDDeleteServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BufferedReader reader = request.getReader();
        JsonObject jsonData = JsonParser.parseReader(reader).getAsJsonObject();
        int drdId = jsonData.get("id").getAsInt();

        DriverDetail drd = new DriverDetail();
        drd.setId(drdId);
        DriverDetail obj = DriDetailDao.retrieveById(drd);
        int dri_id = obj.getDri_id();
        int ord_id = obj.getOrd_id();
        int status = DriDetailDao.delete(drd);

        PrintWriter out = response.getWriter();
        JsonObject responseObject = new JsonObject();
        response.setContentType("application/json");
        if(status>0){
            responseObject.addProperty("status","success");
            responseObject.addProperty("comment","Driver details deleted successfully");

            //changing status of driver and order if order is delivered
            DriverDao.changeStatus(dri_id,"free");
            OrderDao.changeStatus(ord_id,"ordered");
        }
        else{
            responseObject.addProperty("status","failed");
            responseObject.addProperty("comment","Driver details not deleted");
        }
        out.print(responseObject);
        out.flush();
    }
}