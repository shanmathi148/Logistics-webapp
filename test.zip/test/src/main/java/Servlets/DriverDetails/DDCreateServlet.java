package Servlets.DriverDetails;

import Dao.*;
import Data.Customer;
import Data.DriverDetail;
import Data.Order;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet(name = "DDCreateServlet", value = "/DDCreateServlet")
public class DDCreateServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
    private Gson gson = new Gson();
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BufferedReader reader = request.getReader();
        JsonObject jsonData = JsonParser.parseReader(reader).getAsJsonObject();
        int o_id = jsonData.get("o_id").getAsInt();
        int d_id = jsonData.get("d_id").getAsInt();
        PrintWriter out = response.getWriter();

        //finding hub id from customers
        Order o = new Order();
        o.setId(o_id);
        OrderDao dao = new OrderDao();
        Order od = dao.retrieveById(o);
        int custId = od.getC_id();
        Customer cust = new Customer();
        cust.setId(custId);
        Customer c = CustDao.retrieveById(cust);
        String h_loc = c.getLocation();
        int h_id = HubDao.retrieveByLoc(h_loc);

        DriverDetail drd = new DriverDetail();
        drd.setOrd_id(o_id);
        drd.setDri_id(d_id);
        if(h_id > 0) {
            drd.setHub_id(h_id);
        }
        else{
            out.print("Services not available for the customer location\n");
        }
        int status = 1;

        //checking whether o_id already exists
        List<DriverDetail> driDetails = DriDetailDao.retrieve();
        for(DriverDetail obj : driDetails){
            if(obj.getOrd_id() == o_id){
                status = 0;
                break;
            }
        }
        if(status==1) {
            status = DriDetailDao.create(drd);
        }

        String drdJsonString = this.gson.toJson(drd);
        JsonElement drdJson = gson.fromJson(drdJsonString,JsonElement.class);
        JsonObject responseObject = new JsonObject();
        response.setContentType("application/json");
        if(status>0){
            responseObject.addProperty("status","success");
            responseObject.addProperty("comment","Driver assigned successfully");
            responseObject.add("data",drdJson);

            //changing driver status
            DriverDao.changeStatus(d_id, "assigned");
        }
        else{
            responseObject.addProperty("status","failed");
            responseObject.addProperty("comment","Driver not assigned");
            responseObject.add("data",drdJson);
        }
        out.print(responseObject);
        out.flush();
    }
}