package Servlets.DriverDetails;

import Dao.DriDetailDao;
import Data.DriverDetail;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "DDRetrieveByIdServlet", value = "/DDRetrieveByIdServlet")
public class DDRetrieveByIdServlet extends HttpServlet {
    private Gson gson = new Gson();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BufferedReader reader = request.getReader();
        JsonObject jsonData = JsonParser.parseReader(reader).getAsJsonObject();
        int drdId = jsonData.get("id").getAsInt();

        DriverDetail drd = new DriverDetail();
        drd.setOrd_id(drdId);
        DriverDetail d = DriDetailDao.retrieveById(drd);

        PrintWriter out = response.getWriter();
        JsonObject responseObject = new JsonObject();
        response.setContentType("application/json");
        String drdJsonString = this.gson.toJson(d);
        JsonElement drdJson = gson.fromJson(drdJsonString,JsonElement.class);
        if(d.getId() != 0){
            responseObject.addProperty("status","success");
            responseObject.addProperty("comment","Driver Details found at the given id");
            responseObject.add("data",drdJson);
        }
        else{
            responseObject.addProperty("status","failed");
            responseObject.addProperty("comment","Driver Details not found");
        }
        out.print(responseObject);
        out.flush();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}