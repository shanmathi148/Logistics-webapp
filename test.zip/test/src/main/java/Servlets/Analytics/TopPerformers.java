package Servlets.Analytics;

import Dao.Analytics;
import Dao.DriDetailDao;
import Dao.DriverDao;
import Dao.OrderDao;
import Data.DriverDetail;
import Data.Drivers;
import Data.Order;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

@WebServlet(name = "TopPerformers", value = "/TopPerformers")
public class TopPerformers extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BufferedReader reader = request.getReader();
        JsonObject jsonData = JsonParser.parseReader(reader).getAsJsonObject();
        String range = jsonData.get("range").getAsString();
        LocalDate formatDate = LocalDate.now();
        DateTimeFormatter formatType = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        String today = formatDate.format(formatType);

        //finding the startDate and endDate of the given range
        String startDate = Analytics.findStartDate(formatDate,range);
        String endDate = today;

        //retrieving orders that are within date range and updating the drivers_order_count
        HashMap<Integer, Integer> drivers_order_count = new HashMap<>();
        List<Order> orders = OrderDao.retrieve();
        for(Order o : orders){
            String date = o.getDate();
            int o_id = o.getId();
            if(Analytics.checkDateRange(startDate,endDate,date)){
                DriverDetail dd = new DriverDetail();
                dd.setOrd_id(o_id);
                DriverDetail drd = DriDetailDao.retrieveById(dd);
                int dri_id = drd.getDri_id();
                Integer count = drivers_order_count.get(dri_id);
                if(count == null){
                    drivers_order_count.put(dri_id,1);
                }
                else{
                    drivers_order_count.put(dri_id,count+1);
                }
            }
        }

        LinkedHashMap<Integer, Integer> sorted_do_count = Analytics.sortMap(drivers_order_count);
        PrintWriter out = response.getWriter();
        JsonObject responseObject = new JsonObject();
        response.setContentType("application/json");

        //finding the top three performers
        int printed = 1;
        for (Map.Entry<Integer, Integer> entry : sorted_do_count.entrySet()){
            int dri_id = entry.getKey();
            Drivers d = new Drivers();
            d.setId(dri_id);
            Drivers dr = DriverDao.retrieveById(d);
            responseObject.addProperty(String.valueOf(printed),dr.getName());
            if(printed==3){
                break;
            }
            printed += 1;
        }
        out.print(responseObject);
        out.flush();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}