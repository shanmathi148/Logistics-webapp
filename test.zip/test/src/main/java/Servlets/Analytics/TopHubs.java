package Servlets.Analytics;

import Dao.*;
import Data.DriverDetail;
import Data.Hub;
import Data.Order;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

@WebServlet(name = "TopHubs", value = "/TopHubs")
public class TopHubs extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BufferedReader reader = request.getReader();
        JsonObject jsonData = JsonParser.parseReader(reader).getAsJsonObject();
        String range = jsonData.get("range").getAsString();
        LocalDate formatDate = LocalDate.now();
        DateTimeFormatter formatType = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        String today = formatDate.format(formatType);

        //finding the startDate and endDate of the given range
        String startDate = Analytics.findStartDate(formatDate,range);
        String endDate = today;

        //retrieving orders that are within date range and updating the hubs_order_count
        HashMap<Integer, Integer> hubs_order_count = new HashMap<>();
        List<Order> orders = OrderDao.retrieve();
        for(Order o : orders){
            String date = o.getDate();
            int o_id = o.getId();
            if(Analytics.checkDateRange(startDate,endDate,date)){
                DriverDetail dd = new DriverDetail();
                dd.setOrd_id(o_id);
                DriverDetail drd = DriDetailDao.retrieveById(dd);
                int hub_id = drd.getHub_id();
                Integer count = hubs_order_count.get(hub_id);
                if(count == null){
                    hubs_order_count.put(hub_id,1);
                }
                else{
                    hubs_order_count.put(hub_id,count+1);
                }
            }
        }

        LinkedHashMap<Integer, Integer> sorted_ho_count = Analytics.sortMap(hubs_order_count);
        PrintWriter out = response.getWriter();
        JsonObject responseObject = new JsonObject();
        response.setContentType("application/json");

        //finding the top five hubs receiving highest orders
        int printed = 1;
        for (Map.Entry<Integer, Integer> entry : sorted_ho_count.entrySet()){
            int hub_id = entry.getKey();
            Hub h = new Hub();
            h.setId(hub_id);
            Hub hub = HubDao.retrieveById(h);
            responseObject.addProperty(String.valueOf(printed),hub.getLocation());
            if(printed==5){
                break;
            }
            printed += 1;
        }
        out.print(responseObject);
        out.flush();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}