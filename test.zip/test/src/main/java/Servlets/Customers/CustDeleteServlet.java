package Servlets.Customers;

import Dao.CustDao;
import Data.Customer;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "Servlets.Customers.CustDeleteServlet", value = "/Servlets.Customers.CustDeleteServlet")
public class CustDeleteServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BufferedReader reader = request.getReader();
        JsonObject jsonData = JsonParser.parseReader(reader).getAsJsonObject();
        int custId = jsonData.get("id").getAsInt();

        Customer cust = new Customer();
        cust.setId(custId);
        int status = CustDao.delete(cust);

        PrintWriter out = response.getWriter();
        JsonObject responseObject = new JsonObject();
        response.setContentType("application/json");
        if(status>0){
            responseObject.addProperty("status","success");
            responseObject.addProperty("comment","Customer deleted successfully");
        }
        else{
            responseObject.addProperty("status","failed");
            responseObject.addProperty("comment","Customer not deleted");
        }
        out.print(responseObject);
        out.flush();
    }
}