package Servlets.Customers;

import Dao.CustDao;
import Data.Customer;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet(name = "Servlets.Customers.CustRetrieveServlet", value = "/Servlets.Customers.CustRetrieveServlet")
public class CustRetrieveServlet extends HttpServlet {
    private Gson gson = new Gson();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        response.setContentType("application/json");
        JsonObject responseObject = new JsonObject();
        List<Customer> list = CustDao.retrieve();
        if(!list.isEmpty()) {
            for (Customer c : list) {
                String custJsonString = this.gson.toJson(c);
                out.print(custJsonString);
            }
        }
        else{
            responseObject.addProperty("status","failed");
            responseObject.addProperty("comment","Customer list is empty");
            out.print(responseObject);
        }
        out.flush();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}