package Servlets.Customers;
import Data.*;

import Dao.CustDao;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "Servlets.Customers.CustCreateServlet", value = "/Servlets.Customers.CustCreateServlet")
public class CustCreateServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
    private Gson gson = new Gson();
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BufferedReader reader = request.getReader();
        JsonObject jsonData = JsonParser.parseReader(reader).getAsJsonObject();
        String custName = jsonData.get("name").getAsString();
        String custLoc = jsonData.get("location").getAsString();
        String custPhone = jsonData.get("phone").getAsString();
        String custEmail = jsonData.get("email").getAsString();

        Customer cust = new Customer();
        cust.setName(custName);
        cust.setLocation(custLoc);
        cust.setPhone(custPhone);
        cust.setEmail(custEmail);
        int status = CustDao.create(cust);

        PrintWriter out = response.getWriter();
        String custJsonString = this.gson.toJson(cust);
        JsonElement custJson = gson.fromJson(custJsonString,JsonElement.class);
        JsonObject responseObject = new JsonObject();
        response.setContentType("application/json");
        if(status>0){
            responseObject.addProperty("status","success");
            responseObject.addProperty("comment","Customer added successfully");
            responseObject.add("data",custJson);
        }
        else{
            responseObject.addProperty("status","failed");
            responseObject.addProperty("comment","Customer not added");
        }
        out.print(responseObject);
        out.flush();
    }
}