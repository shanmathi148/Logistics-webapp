package Servlets.Orders;

import Dao.DriDetailDao;
import Dao.OrdDetailDao;
import Dao.OrderDao;
import Data.DriverDetail;
import Data.Order;
import Data.OrderDetail;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet(name = "OrderDeleteServlet", value = "/OrderDeleteServlet")
public class OrderDeleteServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BufferedReader reader = request.getReader();
        JsonObject jsonData = JsonParser.parseReader(reader).getAsJsonObject();
        int ordId = jsonData.get("id").getAsInt();

        PrintWriter out = response.getWriter();
        JsonObject responseObject = new JsonObject();
        response.setContentType("application/json");

        //deleting the related order details
        OrderDetail od = new OrderDetail();
        od.setO_id(ordId);
        List<OrderDetail> list = OrdDetailDao.retrieveById(od);
        if(!list.isEmpty()) {
            for (OrderDetail o : list) {
                int stat = OrdDetailDao.delete(o);
            }
        }

        //deleting the driver details
        DriverDetail dd = new DriverDetail();
        dd.setOrd_id(ordId);
        DriverDetail drd = DriDetailDao.retrieveById(dd);
        DriverDetail dobj = new DriverDetail();
        dobj.setId(drd.getId());
        int stat = DriDetailDao.delete(dobj);

        //deleting the order
        Order ord = new Order();
        ord.setId(ordId);
        int status = OrderDao.delete(ord);

        if(status>0){
            responseObject.addProperty("status","success");
            responseObject.addProperty("comment","Order deleted successfully");
        }
        else{
            responseObject.addProperty("status","failed");
            responseObject.addProperty("comment","Order not deleted");
        }

        out.print(responseObject);
        out.flush();
    }
}