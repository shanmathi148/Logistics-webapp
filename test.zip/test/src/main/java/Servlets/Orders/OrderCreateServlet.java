package Servlets.Orders;

import Conn.SqlConnection;
import Dao.*;
import Data.Customer;
import Data.DriverDetail;
import Data.Drivers;
import Data.Order;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;

@WebServlet(name = "OrderCreateServlet", value = "/OrderCreateServlet")
public class OrderCreateServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    }
    private Gson gson = new Gson();
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BufferedReader reader = request.getReader();
        JsonObject jsonData = JsonParser.parseReader(reader).getAsJsonObject();
        String ordDate = jsonData.get("date").getAsString();
        String ordDes = jsonData.get("description").getAsString();
        int custId = jsonData.get("cust_id").getAsInt();

        Order ord = new Order();
        ord.setDate(ordDate);
        ord.setDescription(ordDes);
        ord.setC_id(custId);
        int ordId = OrderDao.create(ord);

        PrintWriter out = response.getWriter();
        String ordJsonString = this.gson.toJson(ord);
        JsonElement ordJson = gson.fromJson(ordJsonString,JsonElement.class);
        JsonObject responseObject = new JsonObject();
        response.setContentType("application/json");
        if(ordId>0){
            responseObject.addProperty("status","success");
            responseObject.addProperty("comment","Ordered successfully");
            responseObject.add("data",ordJson);

            //assigning driver
            List<Drivers> list = DriverDao.retrieve();
            if(!list.isEmpty()) {
                for (Drivers d : list) {
                    if(d.getStatus().equals("free")){
                        DriverDetail drd = new DriverDetail();
                        drd.setOrd_id(ordId);
                        drd.setDri_id(d.getId());

                        //finding hubId from the customers table
                        Customer cust = new Customer();
                        cust.setId(custId);
                        Customer c = CustDao.retrieveById(cust);
                        String h_loc = c.getLocation();
                        int h_id = HubDao.retrieveByLoc(h_loc);
                        if(h_id > 0) {
                            drd.setHub_id(h_id);
                        }
                        else{
                            out.print("Services not available for the customer location\n");
                            break;
                        }

                        int status = DriDetailDao.create(drd);
                        if(status>0){
                            out.print("Driver assigned successfully\n");
                            DriverDao.changeStatus(d.getId(), "assigned");
                            break;
                        }
                        else{
                            out.print("Driver not assigned\n");
                        }
                    }
                }
            }
            else{
                responseObject.addProperty("status","failed");
                responseObject.addProperty("comment","Driver list is empty");
            }
        }
        else{
            responseObject.addProperty("status","failed");
            responseObject.addProperty("comment","Order Failed");
            responseObject.add("data",ordJson);
        }
        out.print(responseObject);
        out.flush();
    }
}