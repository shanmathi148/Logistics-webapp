package Servlets.Orders;

import Dao.OrderDao;
import Data.Order;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "OrderRetrieveByIdServlet", value = "/OrderRetrieveByIdServlet")
public class OrderRetrieveByIdServlet extends HttpServlet {
    private Gson gson = new Gson();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BufferedReader reader = request.getReader();
        JsonObject jsonData = JsonParser.parseReader(reader).getAsJsonObject();
        int ordId = jsonData.get("id").getAsInt();

        Order ord = new Order();
        ord.setId(ordId);
        OrderDao dao = new OrderDao();
        Order o = dao.retrieveById(ord);

        PrintWriter out = response.getWriter();
        JsonObject responseObject = new JsonObject();
        response.setContentType("application/json");
        String ordJsonString = this.gson.toJson(o);
        JsonElement ordJson = gson.fromJson(ordJsonString,JsonElement.class);
        if(o.getId() != 0){
            responseObject.addProperty("status","success");
            responseObject.addProperty("comment","Order found at the given id");
            responseObject.add("data",ordJson);
        }
        else{
            responseObject.addProperty("status","failed");
            responseObject.addProperty("comment","Order not found");
        }
        out.print(responseObject);
        out.flush();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    }
}