package Servlets.Orders;

import Dao.DriDetailDao;
import Dao.DriverDao;
import Dao.OrderDao;
import Data.DriverDetail;
import Data.Order;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Driver;

@WebServlet(name = "OrderUpdateServlet", value = "/OrderUpdateServlet")
public class OrderUpdateServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
    private Gson gson = new Gson();
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BufferedReader reader = request.getReader();
        JsonObject jsonData = JsonParser.parseReader(reader).getAsJsonObject();
        int ordId = jsonData.get("id").getAsInt();
        String ordDate = jsonData.get("date").getAsString();
        String ordDes = jsonData.get("description").getAsString();
        int custId = jsonData.get("cust_id").getAsInt();
        String ordStatus = jsonData.get("status").getAsString();

        Order ord = new Order();
        ord.setId(ordId);
        ord.setDate(ordDate);
        ord.setDescription(ordDes);
        ord.setC_id(custId);
        ord.setStatus(ordStatus);
        OrderDao dao = new OrderDao();
        int status = dao.update(ord);

        PrintWriter out = response.getWriter();
        String ordJsonString = this.gson.toJson(ord);
        JsonElement ordJson = gson.fromJson(ordJsonString,JsonElement.class);
        JsonObject responseObject = new JsonObject();
        response.setContentType("application/json");
        if(status>0){
            responseObject.addProperty("status","success");
            responseObject.addProperty("comment","Order details updated successfully");
            responseObject.add("data",ordJson);

            //changing status of driver if order is cancelled
            if(ordStatus.equals("cancelled")){
                DriverDetail dd = new DriverDetail();
                dd.setOrd_id(ordId);
                DriverDetail drd = DriDetailDao.retrieveById(dd);
                int id = drd.getId();
                DriDetailDao.changeStatus(id,"cancelled");
                int d_id = drd.getDri_id();
                DriverDao.changeStatus(d_id,"free");
            }
        }
        else{
            responseObject.addProperty("status","failed");
            responseObject.addProperty("comment","Order details not updated");
        }
        out.print(responseObject);
        out.flush();
    }
}