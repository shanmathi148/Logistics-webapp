package Servlets.Hubs;

import Dao.HubDao;
import Data.Hub;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet(name = "HubRetrieveServlet", value = "/HubRetrieveServlet")
public class HubRetrieveServlet extends HttpServlet {
    private Gson gson = new Gson();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        PrintWriter out = response.getWriter();
        response.setContentType("application/json");
        JsonObject responseObject = new JsonObject();
        List<Hub> list = HubDao.retrieve();
        if(!list.isEmpty()) {
            for (Hub h : list) {
                String hubJsonString = this.gson.toJson(h);
                out.print(hubJsonString);
            }
        }
        else{
            responseObject.addProperty("status","failed");
            responseObject.addProperty("comment","Hub list is empty");
            out.print(responseObject);
        }
        out.flush();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}