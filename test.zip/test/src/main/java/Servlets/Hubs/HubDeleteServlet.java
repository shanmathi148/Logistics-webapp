package Servlets.Hubs;

import Dao.HubDao;
import Data.Hub;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "HubDeleteServlet", value = "/HubDeleteServlet")
public class HubDeleteServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BufferedReader reader = request.getReader();
        JsonObject jsonData = JsonParser.parseReader(reader).getAsJsonObject();
        int hubId = jsonData.get("id").getAsInt();

        Hub hub = new Hub();
        hub.setId(hubId);
        int status = HubDao.delete(hub);

        PrintWriter out = response.getWriter();
        JsonObject responseObject = new JsonObject();
        response.setContentType("application/json");
        if(status>0){
            responseObject.addProperty("status","success");
            responseObject.addProperty("comment","Hub deleted successfully");
        }
        else{
            responseObject.addProperty("status","failed");
            responseObject.addProperty("comment","Hub not deleted");
        }
        out.print(responseObject);
        out.flush();
    }
}