package Servlets.Drivers;

import Dao.DriverDao;
import Data.Drivers;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "DrivCreateServlet", value = "/DrivCreateServlet")
public class DrivCreateServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
    private Gson gson = new Gson();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BufferedReader reader = request.getReader();
        JsonObject jsonData = JsonParser.parseReader(reader).getAsJsonObject();
        String driName = jsonData.get("name").getAsString();
        String driPhone = jsonData.get("phone").getAsString();

        Drivers dri = new Drivers();
        dri.setName(driName);
        dri.setPhone(driPhone);
        int status = DriverDao.create(dri);

        PrintWriter out = response.getWriter();
        String driJsonString = this.gson.toJson(dri);
        JsonElement driJson = gson.fromJson(driJsonString,JsonElement.class);
        JsonObject responseObject = new JsonObject();
        response.setContentType("application/json");
        if(status>0){
            responseObject.addProperty("status","success");
            responseObject.addProperty("comment","Driver added successfully");
            responseObject.add("data",driJson);
        }
        else{
            responseObject.addProperty("status","failed");
            responseObject.addProperty("comment","Driver not added");
        }
        out.print(responseObject);
        out.flush();
    }
}