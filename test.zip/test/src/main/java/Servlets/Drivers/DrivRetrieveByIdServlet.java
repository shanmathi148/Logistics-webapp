package Servlets.Drivers;

import Dao.DriverDao;
import Data.Drivers;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "DrivRetrieveByIdServlet", value = "/DrivRetrieveByIdServlet")
public class DrivRetrieveByIdServlet extends HttpServlet {
    private Gson gson = new Gson();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BufferedReader reader = request.getReader();
        JsonObject jsonData = JsonParser.parseReader(reader).getAsJsonObject();
        int driId = jsonData.get("id").getAsInt();

        Drivers dri = new Drivers();
        dri.setId(driId);
        Drivers d = DriverDao.retrieveById(dri);

        PrintWriter out = response.getWriter();
        JsonObject responseObject = new JsonObject();
        response.setContentType("application/json");
        String driJsonString = this.gson.toJson(d);
        JsonElement driJson = gson.fromJson(driJsonString,JsonElement.class);
        if(d.getId() != 0){
            responseObject.addProperty("status","success");
            responseObject.addProperty("comment","Driver found at the given id");
            responseObject.add("data",driJson);
        }
        else{
            responseObject.addProperty("status","failed");
            responseObject.addProperty("comment","Driver not found");
        }
        out.print(responseObject);
        out.flush();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}