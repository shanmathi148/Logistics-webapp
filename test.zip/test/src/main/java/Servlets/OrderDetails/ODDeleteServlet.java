package Servlets.OrderDetails;

import Dao.OrdDetailDao;
import Dao.OrderDao;
import Data.OrderDetail;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "ODDeleteServlet", value = "/ODDeleteServlet")
public class ODDeleteServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BufferedReader reader = request.getReader();
        JsonObject jsonData = JsonParser.parseReader(reader).getAsJsonObject();
        int ordId = jsonData.get("id").getAsInt();

        //Storing the subTotal before deleting the order details
        OrderDetail o = OrdDetailDao.retrieveByODid(ordId);
        int o_id = o.getO_id();
        double subTotal = -(o.getSub_total());

        OrderDetail ord = new OrderDetail();
        ord.setId(ordId);
        int status = OrdDetailDao.delete(ord);

        PrintWriter out = response.getWriter();
        JsonObject responseObject = new JsonObject();
        response.setContentType("application/json");
        if(status>0){
            responseObject.addProperty("status","success");
            responseObject.addProperty("comment","Order details deleted successfully");

            //changing the total in orders
            OrderDetail od = new OrderDetail();
            od.setO_id(o_id);
            od.setSub_total(subTotal);
            OrderDao.calculateTotal(od);
        }
        else{
            responseObject.addProperty("status","failed");
            responseObject.addProperty("comment","Order details not deleted");
        }
        out.print(responseObject);
        out.flush();
    }
}