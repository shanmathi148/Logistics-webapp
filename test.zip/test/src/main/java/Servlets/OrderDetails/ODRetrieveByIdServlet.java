package Servlets.OrderDetails;

import Dao.OrdDetailDao;
import Data.OrderDetail;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

@WebServlet(name = "ODRetrieveByIdServlet", value = "/ODRetrieveByIdServlet")
public class ODRetrieveByIdServlet extends HttpServlet {
    private Gson gson = new Gson();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BufferedReader reader = request.getReader();
        JsonObject jsonData = JsonParser.parseReader(reader).getAsJsonObject();
        int ordId = jsonData.get("id").getAsInt();

        OrderDetail od = new OrderDetail();
        od.setO_id(ordId);

        PrintWriter out = response.getWriter();
        response.setContentType("application/json");
        JsonObject responseObject = new JsonObject();
        List<OrderDetail> list = OrdDetailDao.retrieveById(od);
        if(!list.isEmpty()) {
            for (OrderDetail o : list) {
                String prodJsonString = this.gson.toJson(o);
                out.print(prodJsonString);
            }
        }
        else{
            responseObject.addProperty("status","failed");
            responseObject.addProperty("comment","Order details not found");
            out.print(responseObject);
        }
        out.flush();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}