package Servlets.OrderDetails;

import Dao.OrdDetailDao;
import Dao.OrderDao;
import Dao.ProdDao;
import Data.OrderDetail;
import Data.Product;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "ODCreateServlet", value = "/ODCreateServlet")
public class ODCreateServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
    private Gson gson = new Gson();
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BufferedReader reader = request.getReader();
        JsonObject jsonData = JsonParser.parseReader(reader).getAsJsonObject();
        int ordId = jsonData.get("o_id").getAsInt();
        int prodId = jsonData.get("p_id").getAsInt();
        int prodCount = jsonData.get("count").getAsInt();

        //calculating subTotal
        double subTotal = OrdDetailDao.cal_subTotal(prodId,prodCount);

        OrderDetail od = new OrderDetail();
        od.setO_id(ordId);
        od.setP_id(prodId);
        od.setP_count(prodCount);
        od.setSub_total(subTotal);
        int status = OrdDetailDao.create(od);

        PrintWriter out = response.getWriter();
        String ordJsonString = this.gson.toJson(od);
        JsonElement ordJson = gson.fromJson(ordJsonString,JsonElement.class);
        JsonObject responseObject = new JsonObject();
        response.setContentType("application/json");
        if(status>0){
            responseObject.addProperty("status","success");
            responseObject.addProperty("comment","Order details created successfully");
            responseObject.add("data",ordJson);
            OrderDao.calculateTotal(od);
        }
        else{
            responseObject.addProperty("status","failed");
            responseObject.addProperty("comment","Order details not created");
        }
        out.print(responseObject);
        out.flush();
    }
}