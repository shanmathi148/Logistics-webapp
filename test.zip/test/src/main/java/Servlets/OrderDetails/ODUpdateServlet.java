package Servlets.OrderDetails;

import Dao.OrdDetailDao;
import Dao.OrderDao;
import Data.OrderDetail;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "ODUpdateServlet", value = "/ODUpdateServlet")
public class ODUpdateServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    }
    private Gson gson = new Gson();
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        BufferedReader reader = request.getReader();
        JsonObject jsonData = JsonParser.parseReader(reader).getAsJsonObject();
        int id = jsonData.get("id").getAsInt();
        int ordId = jsonData.get("o_id").getAsInt();
        int prodId = jsonData.get("p_id").getAsInt();
        int prodCount = jsonData.get("count").getAsInt();

        //calculating new subTotal
        double old_subTotal = OrdDetailDao.retrieveByODid(id).getSub_total();
        double new_subTotal = OrdDetailDao.cal_subTotal(prodId,prodCount);
        double diff_subTotal = new_subTotal - old_subTotal;

        OrderDetail ord = new OrderDetail();
        ord.setId(id);
        ord.setO_id(ordId);
        ord.setP_id(prodId);
        ord.setP_count(prodCount);
        ord.setSub_total(new_subTotal);
        int status = OrdDetailDao.update(ord);

        PrintWriter out = response.getWriter();
        String ordJsonString = this.gson.toJson(ord);
        JsonElement ordJson = gson.fromJson(ordJsonString,JsonElement.class);
        JsonObject responseObject = new JsonObject();
        response.setContentType("application/json");
        if(status>0){
            responseObject.addProperty("status","success");
            responseObject.addProperty("comment","Order details updated successfully");
            responseObject.add("data",ordJson);

            //calculating total price in orders
            OrderDetail od = new OrderDetail();
            od.setO_id(ordId);
            od.setSub_total(diff_subTotal);
            OrderDao.calculateTotal(od);
        }
        else{
            responseObject.addProperty("status","failed");
            responseObject.addProperty("comment","Order details not updated");
        }
        out.print(responseObject);
        out.flush();
    }
}